package gui;

import models.*;
import service.*;
import util.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.util.List;

public class AttendancePanel extends JPanel {

    private final Undergraduate     student;
    private final AttendanceService svc = new AttendanceService();
    private StyledTable table;
    private JLabel      pctLabel;

    public AttendancePanel(Undergraduate student) {
        this.student = student;
        setBackground(UITheme.ALMOND);
        setLayout(new BorderLayout(0, 12));
        setBorder(new EmptyBorder(28, 30, 28, 30));
        build();
    }

    private void build() {
        // Top bar: header + live percentage
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setOpaque(false);
        topBar.setBorder(new EmptyBorder(0, 0, 16, 0));

        topBar.add(makeHeaderLabel("Attendance Record"), BorderLayout.WEST);

        double pct = svc.getAttendancePercent(student.getUgId());
        pctLabel = new JLabel(String.format("%.1f%% Attendance", pct));
        pctLabel.setFont(UITheme.F_BODY_B);
        pctLabel.setForeground(pct >= 80 ? UITheme.STATUS_GREEN : UITheme.STATUS_RED);
        topBar.add(pctLabel, BorderLayout.EAST);

        add(topBar, BorderLayout.NORTH);

        // Table
        String[] cols = {"Week", "Date", "Course", "Type", "Time Slot", "Status"};
        table = new StyledTable(cols);
        loadData();
        add(UITheme.scrollPane(table), BorderLayout.CENTER);
    }

    private void loadData() {
        List<Attendance> list = svc.getAttendance(student.getUgId());
        table.clearRows();
        for (Attendance a : list) {
            table.addRow(new Object[]{
                "W" + a.getWeekNo(),
                DateFormatter.shortFormat(a.getDate()),
                a.getCName(),
                a.getSessionType(),
                a.getTimeSlot(),
                a.getStatus()
            });
        }
    }

    private JLabel makeHeaderLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(UITheme.F_HEADING);
        lbl.setForeground(UITheme.ESPRESSO);
        return lbl;
    }
}
