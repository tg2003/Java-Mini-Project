package dao;

import db.DBConnection;
import models.Attendance;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for ATTENDANCE table.
 */
public class AttendanceDAO {

    /** Full attendance history for a student, newest first. */
    public List<Attendance> getByStudent(String ugId) {
        List<Attendance> list = new ArrayList<>();
        String sql = "SELECT a.Week_no, a.Ug_id, a.Timetable_id, a.Date, " +
                     "a.Techoff_id, a.Status, " +
                     "t.Day, t.Start_time, t.End_time, t.C_code, t.Type, " +
                     "c.C_name " +
                     "FROM ATTENDANCE a " +
                     "JOIN TIMETABLE t ON a.Timetable_id = t.Timetable_id " +
                     "JOIN COURSE c ON t.C_code = c.C_code " +
                     "WHERE a.Ug_id = ? " +
                     "ORDER BY a.Date DESC, a.Timetable_id";
        try (PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, ugId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Attendance(
                    rs.getInt("Week_no"),
                    rs.getString("Ug_id"),
                    rs.getInt("Timetable_id"),
                    rs.getDate("Date"),
                    rs.getString("Status"),
                    rs.getString("Day"),
                    rs.getString("Start_time"),
                    rs.getString("End_time"),
                    rs.getString("C_code"),
                    rs.getString("C_name"),
                    rs.getString("Type")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    /** Attendance percentage for a student across all sessions. */
    public double getAttendancePercentage(String ugId) {
        String sql = "SELECT " +
                     "COUNT(*) AS total, " +
                     "SUM(CASE WHEN Status IN ('Present','MedicalApproved') THEN 1 ELSE 0 END) AS attended " +
                     "FROM ATTENDANCE WHERE Ug_id = ?";
        try (PreparedStatement ps = DBConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, ugId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int total    = rs.getInt("total");
                int attended = rs.getInt("attended");
                if (total == 0) return 0.0;
                return (attended * 100.0) / total;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0.0;
    }
}
